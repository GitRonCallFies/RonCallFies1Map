scoreboard objectives add ScoreToHealth dummy {"text":"プレイヤーをこの体力にする(*0.01HP)"}
scoreboard objectives add ScoreToMaxHealth dummy {"text":"プレイヤーをこの最大体力にする(*0.0001HP)"}
scoreboard objectives add STMHBackup dummy {"text":"ScoreToMaxHealthのBackup"}
