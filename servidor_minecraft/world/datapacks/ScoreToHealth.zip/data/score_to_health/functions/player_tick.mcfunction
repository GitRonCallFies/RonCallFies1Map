execute if entity @s[tag=ScoreToHealth.Modified] run function score_to_health:restore
execute unless score @s STMHBackup matches -2147483648.. run scoreboard players set @s ScoreToMaxHealth 200000
execute unless score @s STMHBackup matches -2147483648.. run scoreboard players set @s STMHBackup 200000
execute if entity @s[tag=!ScoreToHealth.Return,tag=!ScoreToHealth.AntiGlitch.UnsafeTick] unless score @s ScoreToMaxHealth = @s STMHBackup run function score_to_health:modify_max_health
execute unless entity @s[tag=ScoreToHealth.Return] if score @s ScoreToHealth matches -2147483648.. run function score_to_health:check
tag @s[tag=ScoreToHealth.Return] remove ScoreToHealth.Return
advancement revoke @s only score_to_health:player_tick