function natural_merge_sort:sys/sort
execute unless data storage natural_merge_sort: ListDesc[0] run function natural_merge_sort:sys/descend
data modify storage lib: Array set from storage natural_merge_sort: ListDesc[0]
scoreboard players reset $Value1 Temporary
scoreboard players reset $Value2 Temporary