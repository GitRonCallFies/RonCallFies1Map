data modify storage natural_merge_sort: ListDesc set value []
scoreboard players set $Value2 Temporary -2147483648
execute if data storage lib: Array[0] run function natural_merge_sort:sys/setup
function natural_merge_sort:sys/ascend