#> api:mob/summon
#
# MobAssetの召喚処理を叩く処理
#
# @input storage api:
#   Argument.ID : int
#   Argument.FieldOverride? : compound
#   Argument.PreInitInterceptFn?: id(minecraft:function)
# @api

# validate
    execute unless data storage api: Argument.ID run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.miss_args","with":[{"text":"ID","color":"red"}]}]
    execute if data storage global {IsProduction:false} unless loaded ~ ~ ~ run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.summon_unloaded_chunk.mob","color":"white"}]
# 呼び出し
    execute if data storage api: Argument.ID run function api:mob/core/summon
# リセット
    data remove storage api: Argument.ID
    data remove storage api: Argument.FieldOverride
    data remove storage api: Argument.PreInitInterceptFn
