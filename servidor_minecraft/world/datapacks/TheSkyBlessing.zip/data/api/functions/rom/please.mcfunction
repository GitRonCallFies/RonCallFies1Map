#> api:rom/please
#
#
#
# @input storage api: Argument.Address : int @ 0..65535
# @api

# validate
    execute unless data storage api: Argument.Address run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.miss_args","with":[{"text":"Address","color":"red"}]}]
# 新たに提供する必要があるかをチェックする
    execute store result score $Address Temporary run data get storage api: Argument.Address
# validate 2
    execute unless score $Address Temporary matches 0..65535 run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.invalid_rom_address","color":"white","with":[{"score":{"name":"$Address","objective":"Temporary"}}]}]
# 必要な場合は提供する
    execute unless score $Address Temporary = $LatestProvidedAddress Global run function rom:provide
# リセット
    data remove storage api: Argument.Address
