#> api:modifier/heal/get
#
#
#
# @input as player
# @output storage api:
#   Return.Heal : double
# @api

execute if entity @s[type=!player] run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.non_player_target","color":"white","with":[{"text":"api:modifier/heal/get"}]}]

function oh_my_dat:please
data remove storage api: Return.Heal
data modify storage api: Return.Heal set from storage oh_my_dat: _[-4][-4][-4][-4][-4][-4][-4][-4].Attributes.Value.Heal
