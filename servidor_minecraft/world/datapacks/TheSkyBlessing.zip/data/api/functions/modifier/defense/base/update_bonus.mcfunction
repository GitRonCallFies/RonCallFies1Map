#> api:modifier/defense/base/update_bonus
#
# 祝福による補正を更新する
#
# @api

#> Diff
# @private
    #declare score_holder $Diff
    #declare score_holder $RemovedAmount
    #declare score_holder $isNegative

# 古いのをremove
    data modify storage api: Argument.UUID set value [I;1,1,2,0]
    function api:modifier/defense/base/remove
# 差分にする
    scoreboard players operation $Diff Temporary = $BonusDefense Global
    execute store result score $RemovedAmount Temporary run data get storage api: Removed.Amount 100
    execute unless score $RemovedAmount Temporary matches -2147483648..2147483647 run scoreboard players set $RemovedAmount Temporary 0
    scoreboard players operation $Diff Temporary -= $RemovedAmount Temporary
# 出力
    execute store result score $isNegative Temporary if score $Diff Temporary matches ..-1
    execute if score $isNegative Temporary matches 1 run scoreboard players operation $Diff Temporary *= $-1 Const
    execute if score $isNegative Temporary matches 0 if score $Diff Temporary matches 1.. run tellraw @s {"translate":"api.modifier.add.mult","with":[{"translate":"api.modifier.def"},{"score":{"name":"$Diff","objective":"Temporary"},"color":"aqua"}]}
    execute if score $isNegative Temporary matches 1 if score $Diff Temporary matches 1.. run tellraw @s {"translate":"api.modifier.remove.mult","with":[{"translate":"api.modifier.def"},{"score":{"name":"$Diff","objective":"Temporary"},"color":"aqua"}]}
# リセット
    scoreboard players reset $Diff Temporary
    scoreboard players reset $RemovedAmount Temporary
    scoreboard players reset $isNegative Temporary

# 適用
    data modify storage api: Argument set value {Amount:-1,UUID:[I;1,1,2,0],Operation:"multiply"}
    execute store result storage api: Argument.Amount double 0.01 run scoreboard players get $BonusDefense Global
    function api:modifier/defense/base/add
