#> api:modifier/core/common/validate_remove
#
#
#
# @within function api:modifier/**/remove

execute unless data storage api: Argument.UUID run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.miss_args","with":[{"text":"UUID","color":"red"}]}]
