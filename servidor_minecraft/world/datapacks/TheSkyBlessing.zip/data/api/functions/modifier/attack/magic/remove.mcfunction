#> api:modifier/attack/magic/remove
#
#
#
# @input
#   as player
#   storage api:
#       Argument.UUID : [int] @ 4
# @output storage api: Removed
# @api

# データ検証
    function api:modifier/core/common/validate_remove
    execute if entity @s[type=!player] run return run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.non_player_target","color":"white","with":[{"text":"api:modifier/attack/*/remove"}]}]
# データが正しいなら消す
    execute if data storage api: Argument.UUID run function api:modifier/core/attack/magic/remove
# リセット
    data remove storage api: Argument.UUID
