#> api:modifier/fall_resistance/get
#
#
#
# @input as player
# @output storage api:
#   Return.FallResistance : double
# @api

execute if entity @s[type=!player] run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.non_player_target","color":"white","with":[{"text":"api:modifier/fall_resistance/get"}]}]

function oh_my_dat:please
data remove storage api: Return.FallResistance
data modify storage api: Return.FallResistance set from storage oh_my_dat: _[-4][-4][-4][-4][-4][-4][-4][-4].Attributes.Value.FallResistance
