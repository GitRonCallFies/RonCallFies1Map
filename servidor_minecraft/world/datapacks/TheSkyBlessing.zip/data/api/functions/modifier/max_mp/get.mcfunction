#> api:modifier/max_mp/get
#
#
#
# @input as player
# @output storage api:
#   Return.MaxMP : double
# @api

execute if entity @s[type=!player] run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.non_player_target","color":"white","with":[{"text":"api:modifier/max_mp/get"}]}]

function oh_my_dat:please
data remove storage api: Return.MaxMP
execute store result storage api: Return.MaxMP double 1 run data get storage oh_my_dat: _[-4][-4][-4][-4][-4][-4][-4][-4].Attributes.Value.MaxMP
