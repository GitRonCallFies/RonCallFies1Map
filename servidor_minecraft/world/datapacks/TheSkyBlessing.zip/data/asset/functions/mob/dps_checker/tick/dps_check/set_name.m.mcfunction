#> asset:mob/dps_checker/tick/dps_check/set_name.m
# @within function asset:mob/dps_checker/tick/dps_check/*

$data modify entity @s CustomName set value '{"translate":"mob.dummy.name.dps","color":"$(Color)","with":[{"text":"$(DPS)"}]}'
