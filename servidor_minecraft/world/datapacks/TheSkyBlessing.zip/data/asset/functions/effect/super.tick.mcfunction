#> asset:effect/super.tick
#
#
#
# @within function asset:effect/*/tick/

# IDをアドレスとしてROMを呼び出す
    data modify storage api: Argument.Address set from storage asset:context id
    function api:rom/please

# validate
    execute unless data storage rom: _[-4][-4][-4][-4][-4][-4][-4][-4].Effect.Extends run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.effect.extends_fail","with":[{"storage":"asset:context","nbt":"id"}]}]

# 既存のasset:context idを退避させる
    function asset_manager:common/context/id/stash

# ROMから継承元の情報を持ってくる
    data modify storage asset:context id set from storage rom: _[-4][-4][-4][-4][-4][-4][-4][-4].Effect.Extends

# super.tick呼び出し
    execute if data storage asset:context id run function #asset:effect/tick

# 退避させたasset:context idを戻す
    function asset_manager:common/context/id/pop
