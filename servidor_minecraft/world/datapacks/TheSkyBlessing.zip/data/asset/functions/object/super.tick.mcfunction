#> asset:object/super.tick
#
# 継承元の処理も呼び出す時に使う
#
# @within function asset:object/*/tick/

function asset_manager:object/tick/call_super_methods/
