#> asset:object/extends/foreach
#
#
#
# @within function asset:object/extends**

# IDを取得
    data modify storage asset:context id set from storage asset:object CopiedExtends[-1][0]

# 取得したIDを用いてマクロを実行する
    function asset_manager:object/summon/register.m with storage asset:context

# データチェック
    execute unless data storage asset:object ID run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.object.nonexistent","with":[{"storage":"asset:context","nbt":"id"}]}]
    execute unless data storage asset:object {ExtendsSafe:true} run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.object.nonexistent_extends","with":[{"storage":"asset:context","nbt":"id"}]}]
    execute if data storage asset:object IsFirstExtend[-1]._{_:false} unless data storage asset:object {IsAbstract:true} run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.object.extends_nonabstract","with":[{"storage":"asset:context","nbt":"id"}]}]
    execute if data storage asset:object IsFirstExtend[-1]._{_:false} unless data storage asset:object {IsAbstract:true} run tellraw @a [{"storage":"global","nbt":"Prefix.ERROR"},{"translate":"error.object.extends_nonabstract.cause","with":[{"storage":"asset:context","nbt":"id"}]}]

# リセット
    data remove storage asset:object ExtendsSafe

# 先頭削除 (Extends が十分に小さいことがわかっているため先頭再帰する)
    data remove storage asset:object CopiedExtends[-1][0]

# 最初の継承じゃないことをマークする
    data modify storage asset:object IsFirstExtend[-1]._._ set value false

# 要素があれば再帰
    execute if data storage asset:object CopiedExtends[-1][0] run function asset:object/extends/foreach
