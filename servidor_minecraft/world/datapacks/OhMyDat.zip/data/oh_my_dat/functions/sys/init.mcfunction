data modify storage oh_my_dat: two_empty_lists set value [[],[]]
data modify storage oh_my_dat: three_empty_lists set value [[],[],[]]
data modify storage oh_my_dat: two_empty_maps set value [{},{}]
data modify storage oh_my_dat: three_empty_maps set value [{},{},{}]
data modify storage oh_my_dat: initial set value [[[[[[[[{},{},{},{}],[],[],[]],[],[],[]],[],[],[]],[],[],[]],[],[],[]],[],[],[]],[],[],[]]
data modify storage oh_my_dat: _ set from storage oh_my_dat: initial
data modify storage oh_my_dat: id set value [0]
data modify storage oh_my_dat: IDSet set value [I;]
scoreboard objectives add OhMyDatID dummy
scoreboard objectives add OhMyDat dummy