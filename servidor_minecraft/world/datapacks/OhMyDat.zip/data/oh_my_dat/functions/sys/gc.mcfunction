data modify storage oh_my_dat: id append from storage oh_my_dat: id[0]
data remove storage oh_my_dat: id[0]
execute store result score $ OhMyDat run data get storage oh_my_dat: id[0]
scoreboard players remove $ OhMyDat 2147483647
scoreboard players set $ OhMyDatID 0
scoreboard players operation * OhMyDatID -= $ OhMyDat
scoreboard players operation $ OhMyDatID > * OhMyDatID
scoreboard players operation * OhMyDatID += $ OhMyDat
scoreboard players operation $ OhMyDat >< $ OhMyDatID
execute store result score $ OhMyDatID run data get storage oh_my_dat: id[0]
execute if score $ OhMyDatID > $ OhMyDat run function oh_my_dat:sys/gc_loop
scoreboard players operation $ OhMyDat >< $ OhMyDatID
execute store result score $ OhMyDat run data get storage oh_my_dat: id[-1]
execute if score $ OhMyDat matches 0 run scoreboard players add $ OhMyDat 65536
execute if score $ OhMyDatID matches 0 run scoreboard players add $ OhMyDat 65536
execute if score $ OhMyDatID matches 0 run scoreboard players add $ OhMyDatID 65536
scoreboard players operation $ OhMyDat += $ OhMyDat
scoreboard players operation $ OhMyDat -= $ OhMyDatID
scoreboard players operation $ OhMyDat -= $ OhMyDatID
scoreboard players operation $ OhMyDatID -= $ OhMyDat
execute store result score $ OhMyDat run data get storage oh_my_dat: id[1]
scoreboard players operation $ OhMyDatID -= $ OhMyDat
execute if score $ OhMyDatID matches -1.. run function oh_my_dat:sys/gc