execute unless score @s OhMyDatID matches 1.. run function oh_my_dat:sys/allocate
execute unless score @s OhMyDatID = $LatestProvidedID OhMyDatID run scoreboard players operation $ OhMyDatID = @s OhMyDatID
execute unless score @s OhMyDatID = $LatestProvidedID OhMyDatID run function oh_my_dat:sys/provide