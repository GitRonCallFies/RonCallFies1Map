execute if score @s OhMyDatID matches 1.. run function oh_my_dat:please
execute if score @s OhMyDatID matches 1.. run data modify storage oh_my_dat: _[-4][-4][-4][-4][-4][-4][-4][-4] set value {}
scoreboard players reset @s OhMyDatID